# Ansible Collection - zakamaldin.yandex_cloud_elk

Collection with role for creating file with some text
